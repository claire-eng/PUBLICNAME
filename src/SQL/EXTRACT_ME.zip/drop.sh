psql -U postgres -d SOLAR -c "DROP TABLE Program;"
psql -U postgres -d SOLAR -c "DROP TABLE Cost;"
psql -U postgres -d SOLAR -c "DROP TABLE Power;"
psql -U postgres -d SOLAR -c "DROP TABLE Customer;"

psql postgres -c "DROP DATABASE \"SOLAR\";"
