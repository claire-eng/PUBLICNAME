sudo pacman -Syu
sudo pacman -S python-pip python-psycopg2
pip install flask
