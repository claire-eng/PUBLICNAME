SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

createdb SOLAR;

psql -U postgres -d SOLAR -c "CREATE TABLE Customer (
    app_id VARCHAR(50) PRIMARY KEY,
    zip_code VARCHAR(10),
    complete_date DATE,
    contractor VARCHAR(50),
    cust_type VARCHAR(50),
    municipality VARCHAR(50),
    acceptance_date DATE
);"
psql -U postgres -d SOLAR -c "CREATE TABLE Program (
    app_id VARCHAR(50),
    premise_company VARCHAR(50),
    program_name VARCHAR(50),
    municipality VARCHAR(50),
    FOREIGN KEY (app_id) REFERENCES Customer(app_id)
);"

psql -U postgres -d SOLAR -c "CREATE TABLE Cost (
    app_id VARCHAR(50),
    third_ownership VARCHAR(10),
    Interconnection VARCHAR(50),
    FOREIGN KEY (app_id) REFERENCES Customer(app_id)
);"

psql -U postgres -d SOLAR -c "CREATE TABLE Power (
    app_id VARCHAR(50),
    electric_utility VARCHAR(50),
    location VARCHAR(50),
    size_kw FLOAT(6),
    pto_date VARCHAR(50),
    FOREIGN KEY (app_id) REFERENCES Customer(app_id)
);"

psql -U postgres -d SOLAR -c "\i '$SCRIPT_DIR/customerinserts.txt'"
psql -U postgres -d SOLAR -c "\i '$SCRIPT_DIR/programinserts.txt'"
psql -U postgres -d SOLAR -c "\i '$SCRIPT_DIR/costinserts.txt'"
psql -U postgres -d SOLAR -c "\i '$SCRIPT_DIR/powerinserts.txt'"
